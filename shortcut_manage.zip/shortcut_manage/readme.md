#this extensino made for manage any website link to access there

#use guideline

 - add shortcut click plus button
	put name on input fiuld and genarate link that website.
	if it doesn't matche you have to edit the link and click the save button

 - change background image
  click pencil button on the bottom corner and press the link then click save button
  
  
#shortcut manager website link made by appsaeed
	address: appsaeed7@gmail.com
	created date: 13/3/2021
	language: English
	
 
 
